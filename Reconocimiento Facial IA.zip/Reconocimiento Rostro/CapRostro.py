import cv2 #Es una librería open source de visión por computador, análisis de imagen y aprendizaje automático.
import os #Permite crear directorios o enlistar archivos entre otros. 


#Ruta del banco de imagenes donde estan guardados. 
imagenes = "C:/Users/usuario/Desktop/Reconocimiento Rostro/imagenes"
imagenlista = os.listdir(imagenes)


#crear una carpeta donde se almacena los rostros.
if not os.path.exists('RostrosE'):
	print('Carpeta creada: RostrosE')
	os.makedirs('RostrosE')


#Algoritmo pre-Entrenado en la cual detecta donde esta el rostro.
#Link: https://raw.githubusercontent.com/opencv/opencv/master/data/haarcascades/haarcascade_frontalface_default.xml
faceClassif = cv2.CascadeClassifier(cv2.data.haarcascades+ 'haarcascade_frontalface_default.xml')


count = 0
for imageNombre in imagenlista:
    image = cv2.imread(imagenes+'/'+imageNombre) #Especificamos la ruta. 


    #Copia de imagenes:
    imageDup = image.copy() #imagen auxiliar
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) #se transforma a escalas de grises la imegen que entra,
                                                   #aplica la detecion de rostor y coordenadas.
    faces = faceClassif.detectMultiScale(gray, 1.1, 5) #almacenan en la variable face.



    for (x,y,w,h) in faces: #Desempaquetar el alto y ancho de la imagen.
    	cv2.rectangle(image,(x,y),(x+w,y+h),(255,0,0),2)
    

    cv2.putText(image,'',(10,20),2,0.5,(128,0,255),1,cv2.LINE_AA)
    cv2.imshow('image',image) #Dibuja un rectangulo en el rostro.
    k = cv2.waitKey(0)
    

    if k == ord('w'): #accion de recorte del rostro. 
    	for(x,y,w,h) in faces:
    	    rostro = imageDup[y:y+h,x:x+w]
    	    rostro = cv2.resize(rostro,(150,150),interpolation=cv2.INTER_CUBIC)
    	    cv2.imshow('rostro',rostro)
    	    cv2.waitKey(0)
            
            
          




cv2.destroyAllWindows()	